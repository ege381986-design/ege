# PythonAnywhere Kurulum Adımları

## 1. Dosyaları Yükleyin
Bu klasördeki tüm dosya ve klasörleri PythonAnywhere'deki `/home/kullaniciadi/mysite/` dizinine yükleyin.

## 2. Sanal Ortam Kurun
```bash
cd ~
python3.10 -m venv mysite-venv
source mysite-venv/bin/activate
pip install -r mysite/requirements.txt
```

## 3. WSGI Dosyasını Düzenleyin
`/var/www/kullaniciadi_pythonanywhere_com_wsgi.py` dosyasında kullanıcı adınızı güncelleyin.

## 4. Environment Variables
`.env.template` dosyasını `.bashrc` dosyanıza ekleyin (gerçek değerlerle).

## 5. Veritabanı Oluşturun
```bash
cd ~/mysite
python3 -c "from app import app, db; app.app_context().push(); db.create_all(); print('OK')"
```

## 6. Web App'i Reload Edin
PythonAnywhere web app konfigürasyonunda "Reload" butonuna tıklayın.

Detaylı talimatlar için DEPLOYMENT_GUIDE.md dosyasını okuyun.
